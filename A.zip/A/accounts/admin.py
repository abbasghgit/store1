from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import *
from .forms import CustomUserCreationForm,CustomUserChangeForm
# Register your models here.
# create CustomUserAdmin

class CustomUserAdmin(UserAdmin):
   add_form = CustomUserCreationForm
   form = CustomUserChangeForm
   list_display = ['username' ,'role','is_active' ,'is_staff']
   lits_filter = ['username' , 'role' ,'is_active' ,'is_staff']
   fieldsets = (
      (None,{'fields':('username' ,'email' ,'phone' ,'profile_img')}),
      ('permissions',{'fields':('role','is_active','is_staff')})
   )
   add_fieldsets = (
      (None,{'fields':('username' ,'email' ,'phone' ,'profile_img' ,'role' ,'password1' ,'password2' ,'is_active' ,'is_staff')}),
   )
   
   search_fields = ('username',)
   ordering = ('username',)
   
   
admin.site.register(CustomUser,CustomUserAdmin)
admin.site.register(phone_OTP)
admin.site.register(Email_OTP)