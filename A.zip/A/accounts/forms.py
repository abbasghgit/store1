from django import forms
from django.contrib.auth.forms import UserCreationForm,UserChangeForm
from django.core.exceptions import ValidationError
from .models import *
class PasswordReset(forms.ModelForm):
   password1 = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.PasswordInput(attrs={
         "class":"username",
         "placeholder":" پسورد باید 8 کاراکتر داشته باشد",
      })
   )
   password2 = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.PasswordInput(attrs={
         "class":"username",
         "placeholder":" پسورد باید 8 کاراکتر داشته باشد",
      })
   )
   class Meta:
      model = CustomUser
      fields = ('password1' ,'password2')
class LoginForm(forms.Form):
   username = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "class":"username",
         "placeholder":"@نام کاربری",
      })
   )
   password = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.PasswordInput(attrs={
         "class":"username",
         "placeholder":" پسورد باید 8 کاراکتر داشته باشد",
      })
   )
class GetOtpCode(forms.Form):
   code = forms.CharField()

class CustomUserRegisterPhoneForm(forms.ModelForm):
   username = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "class":"username",
         "placeholder":"@نام کاربری",
      })
   )
   phone = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "class":"username",
         "placeholder":"09123451234",
      })
   )
   password = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.PasswordInput(attrs={
         "class":"username",
         "placeholder":" پسورد باید 8 کاراکتر داشته باشد",
      })
   )
   class Meta:
      model = CustomUser
      fields = ('username' ,'phone' ,'password')

class CustomUserRegisterEmailForm(forms.ModelForm):
   username = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.TextInput(attrs={
         "class":"username",
         "placeholder":"@نام کاربری",
      })
   )
   email = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.EmailInput(attrs={
         "class":"username",
         "placeholder":"example@gmail.com",
      })
   )
   password = forms.CharField(
      label='',
      required = True,
      max_length = 155,
      widget=forms.PasswordInput(attrs={
         "class":"username",
         "placeholder":" پسورد باید 8 کاراکتر داشته باشد",
      })
   )
   class Meta:
      model = CustomUser
      fields = ('username' ,'email' ,'password')
   def clean_username(self):
      username = self.cleaned_data['username']
      user = CustomUser.objects.filter(username=username).exists()
      if user:
         raise ValidationError('نام کاربری وجود دارد دوباره امتحان کنید')
      return username 


class CustomUserCreationForm(UserCreationForm):
   class Meta(UserCreationForm):
      model = CustomUser
      fields = ('username','email','phone','profile_img')
      
class CustomUserChangeForm(UserChangeForm):
   class Meta:
      model = CustomUser
      fields = ('username','email','phone','profile_img')