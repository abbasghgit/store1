from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _
from .managers import CustomUserManager
import datetime
# Create your models here.
class CustomUser(AbstractUser):
   ROLES = (
      ('superuser' ,'superuser'),
      ('admin' , 'admin'),
      ('seller' ,'seller'),
      ('customer' , 'customer'),
   )
   username = models.CharField(max_length = 50 ,unique = True)
   email = models.EmailField(_('normal_email'),null = True ,blank=True)
   phone = models.CharField(max_length = 11,blank=True,null=True)
   profile_img = models.ImageField(upload_to = 'photos/%Y/%m/%d' ,blank=True,null=True)
   role = models.CharField(max_length =70 ,choices=ROLES,default = 'customer',blank=False)
   is_seller = models.BooleanField(default = False)
   USERNAME_FIELD = 'username'
   REQUIRED_FIELD = []
   
   objects = CustomUserManager()
   
   def __str__(self):
      return f'{self.username} - {self.email}'
   
   
   
class Email_OTP(models.Model):
   code = models.SmallIntegerField()
   email = models.EmailField(_('normal_email'),unique =True)
   create = models.DateTimeField(default =datetime.datetime.today())
   
   def __str__(self):
      return self.email
   
class phone_OTP(models.Model):
   code = models.SmallIntegerField()
   phone = models.CharField(max_length = 11)
   create = models.DateTimeField(default =datetime.datetime.today())
   
   def __str__(self):
      return self.phone