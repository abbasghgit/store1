from django.core.mail import send_mail

def email(email ,code):
    send_mail(
        'کد تایید شما:',
        f'{code}',
        'abbas123ghavas456@gmail.com',
        [f'{email}'],
        fail_silently =False,
    )