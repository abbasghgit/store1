from .models import Email_OTP,phone_OTP
import datetime
import pytz

def my_task():
    
    t1 = datetime.datetime.today()
    t2 = datetime.timedelta(minutes=2)
    expired_time = t1 - t2
    Email_OTP.objects.filter(create__lt=expired_time).delete()
    phone_OTP.objects.filter(create__lt=expired_time).delete()
    print ("""
 ....................................................\n
 ....................................................\n\n
                    
           otp_code deleted successfully\n

 .....................................................\n
 .....................................................\n        
           
           """)
