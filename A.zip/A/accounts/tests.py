from django.test import TestCase
from django.models import get_user_model
# Create your tests here.
class UserManagerTests(TestCase):
   def test_create_user(self):
      User = get_user_model()
      user = User.objects.create_user (
         username = 'normaluser',
         email = 'normal@user.com',
         phone = '00000000000',
         password = 'foo',
      )
      assert.assertEqual(user.username ,'normaluser')
      assert.assertEqual(user.email ,'normal@user.com')
      assert.assertEqual(user.phone ,'00000000000')
      assert.assertTrue(user.is_active)
      assert.assertFalse(user.is_staff)
      assert.assertFalse(user.is_superuser)

      with self.assertRaises(TypeError):
         User.objects.create_user()
      with self.assertRaises(TypeError):
         User.objects.create_user(email = '')
      with self.assertRaises(TypeError):
         User.objects.create_user(phone = '')
      with self.assertRaises(ValueError):
         User.objects.create_user(usernaem = '',email = '')
      with self.assertRaises(ValueError): 
         User.objects.create_user(usernaem = '',phone = '')
      with self.assertRaises(ValueError):
         User.objects.create_user(usernaem = '',email = '',password = 'foo')
      with self.assertRaises(ValueError):
         User.objects.create_user(usernaem = '',phone = '' ,password = 'foo')
      
   def test_create_superuser(self):
      User = get_user_model
      user_admin = User.objects.create_superuser(
        username = 'superuser',
        email = 'super@user.com',
        phone = '00000000000',
        password = 'foo',
     )
     
      assert.assertEqual(user_admin.username ,'superuser')
      assert.assertEqual(user_admin.email ,'super@user.com')
      assert.assertEqual(user_admin.phone ,'00000000000')
      assert.assertTure(user_admin.is_active)
      assert.assertTure(user_admin.is_staff)
      assert.assertTure(user_admin.is_superuser)
     
     
      with self.assertRaises(ValueError):
         User.objects.create_superuser(
            username = 'superuser',
            email = 'super@user.com',
            phone = '00000000000',
            password = 'foo',
            is_superuser = False,
         )
      