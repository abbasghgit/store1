from django.urls import path
from .views import *

app_name = 'accounts'
urlpatterns = [
    path('login/' ,LoginView.as_view() ,name = 'login'),
    path('logout/' ,LogoutView.as_view() ,name = 'logout'),
    path(
        'signup/',
        CustomUserRegisterView.as_view(),
        name = 'signup'
        ),
    path('email/' ,EmailView.as_view() ,name = 'email'),
    path('phone/' ,PhoneView.as_view() ,name = 'phone'),
    path('verify/' ,CustomUserVerifyView.as_view() ,name = 'verify'),
    path(
        'reset/' ,
        UserPasswordResetView.as_view() ,
        name = 'password_reset'
        ),
    path(
        'reset/done/',
        UserPasswordResetDoneView.as_view(),
        name = 'password_reset_done'
        ),
    path(
        'confirm/<uidb64>/<token>/',
        UserpasswordConfirmView.as_view(),
        name = 'password_reset_confirm'
        ),
    path(
        'complete/',
        UserPasswordCompleteView.as_view(),
        name = 'password_reset_complete'
        ),
    
]