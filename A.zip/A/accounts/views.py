from django.http import HttpRequest
from django.http.response import HttpResponse as HttpResponse
from django.shortcuts import render , redirect
from django.urls import reverse_lazy
from django.views import View
from django.contrib import messages
from django.contrib.auth import login ,logout,authenticate
from django.contrib.auth import views as auth_views
from django.contrib.auth.mixins import LoginRequiredMixin
# کتابخانه های دانلود شده
from django_q.tasks import async_task
from .tasks import my_task
##
from .models import *
from .forms import *
from .otp_code import *
import random
# Create your views here.
# کلاس مربوط به ورود کاربران
class LoginView(View):
   template_name = 'accounts/login.html'
   form_class = LoginForm
   def setup(self ,request,*args ,**kwargs):
      self.next = request.GET.get('next',)
      print(self.next)
      return super().setup(request,*args ,**kwargs)
   def dispatch(self, request, *args, **kwargs):
      if request.user.is_authenticated or request.user.is_superuser :
         return redirect('home:home')
      return super().dispatch(request, *args, **kwargs)
   def get(self ,request):
      context = {'form':self.form_class}
      return render(request ,self.template_name ,context)
   def post(self ,request):
      form = self.form_class(request.POST)
      if form.is_valid():
         cd = form.cleaned_data
         user = authenticate(username = cd['username'] ,password =cd['password'])
         if user is not None:
            login(request,user)
            messages.success(request , 'شما با موفقیت وارد حساب خود شدید', 'success')
            if self.next:
               return redirect(self.next)      
            return redirect('home:home')
         else:
            messages.error(request ,'کلمه عبور یا نام کاربری اشتباه است' ,'danger')
      context = {'form':form}
      return render(request ,self.template_name ,context)
# کلاس مربوط به خروج کاربران

class LogoutView(LoginRequiredMixin ,View):
   def get(self ,request):
      logout(request)
      messages.success(request , 'خروج از حساب با موفقیت انجام شد','info')
      return redirect('home:home')

# کلاس مربوط به ثبت نام کاربران

class CustomUserRegisterView(View):
   template_name = 'accounts/signup.html'
   form_class_phone = CustomUserRegisterPhoneForm
   form_class_email = CustomUserRegisterEmailForm
   def dispatch(self ,request,*args ,**kwargs):
      if request.user.is_authenticated or request.user.is_superuser :
         return redirect('home:home')
      
      return super().dispatch(request,*args,**kwargs)
   def get(self, request):
      phone = self.form_class_phone()
      email = self.form_class_email()
      context = {
         'phone_form':phone,
         'email_form':email,
      }
      return render(request,self.template_name,context)
# ثبت نام با ایمیل
class EmailView(View):
   form_class_email = CustomUserRegisterEmailForm
   def post(self,request):
      form_email = self.form_class_email(request.POST)
      if form_email.is_valid():
         cd = form_email.cleaned_data
         request.session['user_registration_info'] = {
            'username' : cd['username'],
            'email' : cd['email'],
            'password' : cd['password'],
         }
         code = random.randint(1000,9999)
         
         try:
           e = Email_OTP.objects.get(email = cd['email'])
           print(e)
         except:
           q = Email_OTP.objects.create(code = code,email = cd['email'])
           q.save()
           print(f"{q} created")
         email(email = cd['email'],code = code)
         async_task(my_task)
         messages.success(request , 'کد تایید به ایمیل شما ارسال شد' ,'success')
         return redirect('accounts:verify')
      elif request.POST['username'] == '' or request.POST['email'] == '' or request.POST['password'] == '':
         messages.success(request ,'لطفا اطلاعات خود را وارد کنید' ,'danger')
         return redirect('accounts:signup')
      else:
         messages.success(request ,'نام کاربری وجود دارد لطفا نام دیگری وارد کنید' ,'danger')
         return redirect('accounts:signup')
      
# ثبت نام با شماره تلفن
class PhoneView(View):
   form_class_phone = CustomUserRegisterPhoneForm
   def post(self,request):
      form_phone = self.form_class_phone(request.POST)
      if form_phone.is_valid():
         cd = form_phone.cleaned_data
         request.session['user_registration_info'] = {
            'username': cd['username'],
            'phone': cd['phone'],
            'password': cd['password'],
         }
         code = random.randint(1000,9999)
         try:
           e = phone_OTP.objects.get(email = cd['phone'])
           print(e)
         except:
           q = phone_OTP.objects.create(code = code,phone = cd['phone'])
           q.save()
           print(f"{q}phone created")
         async_task(my_task)
         print(code)
         messages.success(request , 'کد تایید به ایمیل شما ارسال شد' ,'success')
         return redirect('accounts:verify')
      elif request.POST['username'] == '' or request.POST['phone'] == '' or request.POST['password'] == '':
         messages.success(request ,'لطفا اطلاعات خود را وارد کنید' ,'danger')
         return redirect('accounts:signup')
      else:
         messages.success(request ,'نام کاربری وجود دارد لطفا نام دیگری وارد کنید' ,'danger')
         return redirect('accounts:signup')
      
      
# کلاس مربوط به اعتبار سنجی کاربران
class CustomUserVerifyView(View):
   form_class = GetOtpCode
   template_name = 'accounts/verify.html'
   def get(self ,request):
      r = request.session
      b =r['user_registration_info']
      context = {'info':b}
      return render(request,self.template_name,context)
   def post(self ,request):
      req = request.session
      data = req['user_registration_info']
      form = self.form_class(request.POST)
      if form.is_valid():
         if data.get('email'):
            otp_code = Email_OTP.objects.get(email=data['email'])
            code = request.POST['code']
            if int(code) == int(otp_code.code):
               user = CustomUser.objects.create_user(
                  username=data['username'],
                  email=data['email'],
                  password=data['password'],
               )
               user.save()
               login(user)
               messages.success(request , 'حساب شما با موفقییت ساخته شد' ,'success')
               return redirect('home:home')
         elif data.get('phone'):
            otp_code = phone_OTP.objects.get(phone=data['phone'])
            code = request.POST['code']
            if int(code) == int(otp_code.code):
               user = CustomUser.objects.create_user(
                  username=data['username'],
                  email= None ,
                  phone=data['phone'],
                  password=data['password'],
               )
               user.save()
               login(request ,user)
               messages.success(request , 'حساب شما با موفقییت ساخته شد' ,'success')
               return redirect('home:home')
      else:
         messages.error(request ,'لطفا اطلاعات را وارد نمایید' ,'danger')
      
      return render(request,self.template_name)
   
# کلاس های مربوط به فراموشی کلمه عبور
class UserPasswordResetView(auth_views.PasswordResetView):
   template_name = 'accounts/password_reset_form.html'
   success_url = reverse_lazy('accounts:password_reset_done')
   email_template_name = 'accounts/password_reset_email.html'

class UserPasswordResetDoneView(auth_views.PasswordResetDoneView):
   template_name = 'accounts/password_reset_done.html'

class UserpasswordConfirmView(auth_views.PasswordResetConfirmView):
   template_name = 'accounts/password_confirm.html'
   success_url = reverse_lazy('accounts:password_reset_complete')

class UserPasswordCompleteView(auth_views.PasswordResetCompleteView):
   template_name = 'accounts/password_reset_complete.html'
