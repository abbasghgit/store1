from django.db import models
from django.urls import reverse
# Create your models here.


class Category(models.Model):
   name = models.CharField(max_length = 155)
   parent = models.ForeignKey(
      'self' ,
      on_delete =models.SET_NULL,
      related_name ='childern',
      blank=True,
      null=True,
   )
   
   class Meta:
      verbose_name_plural = "Categories"
      
   def __str__(self):
      return f'{self.name}'
   
class Brand(models.Model):
   name = models.CharField(max_length = 155)
   brand_img = models.ImageField(upload_to = 'brand/%Y/%m/%d')
   category = models.ForeignKey(Category ,on_delete=models.CASCADE ,related_name ='brands')
   
   def __str__(self):
      return f'{self.name}'
