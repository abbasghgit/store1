from products.models import Product
SESSION_KEY = 'cart_keys'
class Cart:
    def __init__(self ,request):
        self.session = request.session
        cart = self.session.get(SESSION_KEY)
        if SESSION_KEY not in request.session:
            cart = request.session[SESSION_KEY] = {}

        self.cart = cart


    def __iter__(self):
        product_ids = self.cart.keys()
        products = Product.objects.filter(id__in =product_ids)
        for product in products:
            self.cart[str(product.id)]['product'] = product
        cart = self.cart.copy()
        for item in cart.values():
            item['total_price'] = int(item['quantity']) * int(item['price'])

            yield item


    def add_cart(self ,product_id ,quantity):
        product = Product.objects.get(id = product_id)
        if product_id not in self.cart:
# این بخش نیازمند تکمیل است
            if product.is_sale == True:
                get_total = int(product.sale_price) * int(quantity)
                self.cart[str(product.id)] = {
                    'price':str(product.sale_price),
                    'quantity': str(quantity),
                    'total_price': str(get_total),
                }
            else:
                get_total = int(product.price) * int(quantity)
                self.cart[str(product.id)] = {
                    'price':str(product.price),
                    'quantity': str(quantity),
                    'total_price': str(get_total),
                }
        self.save()


    def save(self):
        self.session.modified = True

    def remove_cart(self ,product_id):
        if str(product_id) in self.cart.keys():
            del self.cart[str(product_id)]
        self.save()

    def get_products(self):
        product_ids = self.cart.keys()
        products = Product.objects.filter(id__in = product_ids)
        return products
    
    def get_total_price(self):
        return sum(int(item['total_price']) for item in self.cart.values())

    def items(self):
        return self.cart.copy()

    def __len__(self):
        return len(self.cart.copy())
    
    def clear_cart(self):
        del self.session[SESSION_KEY]
        self.save()