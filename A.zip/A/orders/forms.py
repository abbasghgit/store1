from django import forms
from profiles.models import Customer
class OrderForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ('name','ostan' ,'shahr' ,'addres' ,'phone')