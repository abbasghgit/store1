from django.urls import path
from .views import *
app_name = 'orders'
urlpatterns = [
    path('add_cart/' ,AddCartView ,name = 'add_cart'),
    path('cart/' ,CartView.as_view() ,name = 'cart'),
    path('remove_cart/<int:product_id>/' ,RemoveCartView.as_view() ,name = 'remove_cart'),
    path('create_order/' ,OrderCreateView.as_view() ,name = 'create_order'),
    path('orders/<int:order_id>/' ,OrderView.as_view() ,name = 'orders'),
    path('request/<int:order_id>/', send_request, name='request'),
    path('verify/<int:order_id>/', verify, name='verify'),
]