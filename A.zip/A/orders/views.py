from typing import Any
from django.shortcuts import render , get_object_or_404 ,redirect
from django.http import HttpRequest, HttpResponse ,JsonResponse
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.conf import settings
from products.models import Product
from .cart import Cart
from .zarinpal import ZarinPal
from .models import *
from .forms import *
from iranian_cities.models import Ostan ,Shahr
import json
import requests
# Create your views here.
class CartView(View):
    template_name = 'orders/cart.html'
    def get(self ,request):
#        context = {
 #           'products': products,
  #          'get_total_price':get_total_price,
  #          'quantity':
#}      
        
        return render(request ,self.template_name)
    

def AddCartView(request):
    cart = Cart(request)
    if request.POST.get('action') == 'post':
        product_id = request.POST.get('product_id')
        quantity = request.POST.get('quantity')
        cart.add_cart(product_id=product_id,quantity=quantity)
        qty = cart.__len__()
        return JsonResponse({'qty':qty})
    
class RemoveCartView(View):
    def get(self,request,product_id):
        cart = Cart(request)
        cart.remove_cart(product_id)
        messages.success(request, 'محصول با موفقییت حذف شد','info')
        return redirect('orders:cart')
    
# اتمام سبد خرید

class OrderCreateView(LoginRequiredMixin ,View):
    def get(self ,request):
        order = Order.objects.create(user =request.user)
        cart = Cart(request)
        for item in cart:
            order_item = OrderItem.objects.create(
                order = order,
                product = item['product'],
                price = int(item['price']),
                quantity = int(item['quantity']),
            )
            order_item.save()
        return redirect('orders:orders' ,order.id)# .HINT

class OrderView(LoginRequiredMixin ,View):
    form_class = OrderForm
    template_name = 'orders/orders.html'
    def setup(self, request, *args, **kwargs):
        self.order = get_object_or_404(Order,id=kwargs['order_id'])
        return super().setup(request, *args, **kwargs)
    def dispatch(self, request, *args, **kwargs):
        if request.user != self.order.user:
            messages.error(request ,'خریدار یافت نشد' ,'danger')
            return redirect('orders:cart')
        return super().dispatch(request, *args, **kwargs)
    
    def get(self ,request,*args ,**kwargs):
        sh = request.GET.get('ostan')
        if request.GET.get('ostan'):
            sh = Shahr.objects.filter(ostan__id=request.GET['ostan'])
        context = {'form':self.form_class,'sh':sh}
        return render(request ,self.template_name ,context)
    
    def post(self ,request,*args ,**kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            new_customer = form.save(commit=False)
            new_customer.name = cd['name']
            new_customer.user = request.user
            new_customer.order = self.order
            new_customer.ostan = cd['ostan']
            new_customer.shahr = cd['shahr']
            new_customer.addres = cd['addres']
            new_customer.phone = cd['phone']
            new_customer.save()
            messages.success(request ,'اطلاعات شما در یافت شد' ,'success')
            return redirect('orders:request' ,self.order.id)

    



# درگاه زرین پال


pay = ZarinPal(merchant='5096280d-21ec-4e95-86dd-1d4c0eb34ada', call_back_url="http://localhost:8000/orders/verify/")


def send_request(request ,*args ,**kwargs):
    order = Order.objects.get(id =kwargs['order_id'])
    amount = order.get_total_price()
    request.session['bank_information'] = {
        'order_id':str(kwargs['order_id']),
    }
    
    # email and mobile is optimal
    response = pay.send_request(amount=amount, description='توضیحات مربوط به پرداخت',order_id=order.id,email=request.user.email,
                               mobile=str(request.user.phone))
    if response.get('error_code') is None:
        # redirect object
        return response
    else:
        return HttpResponse(f'Error code: {response.get("error_code")}, Error Message: {response.get("message")}')


def verify(request ,*args ,**kwargs):

    order = Order.objects.get(id = kwargs['order_id'])
    amount = order.get_total_price()
    response = pay.verify(request=request, amount=amount)

    if response.get("transaction"):
        if response.get("pay"):
            return HttpResponse('تراکنش با موفقت انجام شد')
        else:
            return HttpResponse('این تراکنش با موفقیت انجام شده است و الان دوباره verify شده است')
    else:
        if response.get("status") == "ok":
            return HttpResponse(f'Error code: {response.get("error_code")}, Error Message: {response.get("message")}')
        elif response.get("status") == "cancel":
            return HttpResponse(f'تراکنش ناموفق بوده است یا توسط کاربر لغو شده است'
                                f'Error Message: {response.get("message")}')
