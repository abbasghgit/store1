from django.urls import path
from .views import *

app_name = 'products'
urlpatterns = [
    path('single/<int:product_id>/' ,SingleProductsView.as_view() ,name = 'single'),
    path('votes/<int:product_id>/' ,LikeView.as_view() ,name = 'like'),
    path('comments/<int:product_id>/' ,CommentView.as_view() ,name = 'comments'),

]