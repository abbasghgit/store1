from django.shortcuts import render , redirect,get_object_or_404
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from accounts.models import *
from category.models import *
from .models import *
from .forms import *
# Create your views here.
class SingleProductsView(View):
   template_name = 'products/single.html'
   def setup(self ,request ,*args ,**kwargs):
      self.product = get_object_or_404(Product ,pk=kwargs['product_id'])
      return super().setup(request,*args ,**kwargs)
   def get(self ,request ,*args ,**kwargs):
      category = self.product.category
      can_user_like = True
      if request.user.is_authenticated:
         if Product.can_user_like(self.product ,user=request.user):
            can_user_like = False
            
      context = {
         'product':self.product,
         'category':category,
         'can_user_like':can_user_like,
      }
      return render(request,self.template_name ,context)
      
   

class LikeView(View):
   def get(self, request ,product_id):
      user = request.user
      product = Product.objects.get(id =product_id)
      try:
         like = Vote.objects.get(product=product ,user=user)
         like.delete()
         return redirect('products:single' ,product_id)
      except:
         like = Vote.objects.create(product=product,user=user)
         like.save()
         return redirect('products:single' ,product_id)




class CommentView(LoginRequiredMixin ,View):
   form_class = ProductCommentForm
   def post(self ,request,product_id):
      product = Product.objects.get(id=product_id)
      form = self.form_class(request.POST)
      if form.is_valid():
         new_comment = form.save(commit=False)
         new_comment.user = request.user
         new_comment.product = product
         new_comment.available = True
         new_comment.save()
         messages.success(request ,'نظر شما با موفقیت ثبت شد' ,'success')
         return redirect('products:single',product_id )
      return redirect('products:single',product_id )