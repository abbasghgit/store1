from django.db import models

from iranian_cities.fields import OstanField ,ShahrField
from accounts.models import CustomUser
from orders.models import Order
import datetime
# Create your models here.


class Seller(models.Model):
   name = models.CharField(max_length = 155)
   user = models.ForeignKey(
      CustomUser,
      default = 1,
      on_delete = models.SET_DEFAULT,
      related_name = 'seller',
   )
   img = models.TextField(max_length =500)
   shaba = models.CharField(max_length =24 ,blank =True ,null =True)
   card_number = models.CharField(max_length =19 ,blank =True ,null =True)
   description = models.TextField(max_length =500)
   Ostan = OstanField()
   Shar = ShahrField()
   addres = models.TextField(max_length =500)
   phone = models.CharField(max_length =11)
   otp_check = models.BooleanField(default = False)
   available = models.BooleanField(default = False)
   create = models.DateTimeField(default = datetime.datetime.today())
   
   
   def __str__(self):
      return f'{self.name} - {self.phone} - {self.user}'
   
class Customer(models.Model):
   name = models.CharField(max_length = 155)
   user = models.ForeignKey(
      CustomUser,
      on_delete = models.CASCADE,
      related_name = 'customers',
   )
   order = models.ForeignKey(
      Order,
      on_delete = models.CASCADE,
      related_name = 'order_customer'
   )
   ostan = OstanField()
   shahr = ShahrField()
   addres = models.TextField(max_length =500)
   phone = models.CharField(max_length =11 ,blank=True,null=True)
   
   def __str__(self):
      return f'{self.name} - {self.order} - {self.user}'
   
   
   