
function setClose(input ,index){
   let btn = document.querySelector('#'+index);
   let chat = document.querySelector('#'+input);
   chat.classList.add('active');
   btn.classList.remove('active');   
}