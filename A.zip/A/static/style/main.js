let slideIndex = 1;

function setSlide(input ,index){
   slideIndex = index;
   let item = document.querySelector('#'+input);
   let btn = document.querySelector('#b'+index);
   let btns = [...document.querySelector('.btns-box').children]
   btns.forEach((element)=>{
      element.classList.remove('active')
   })
   let slides = [...document.querySelector('.slider-box').children]
   slides.forEach((element)=>{
      element.classList.remove('active');
   })
   item.classList.add('active');
   btn.classList.add('active');
}
setInterval(()=>{
   slideIndex += 1;
   if (slideIndex==4){
      slideIndex = 1;
   }
   setSlide('slide'+slideIndex,slideIndex)
} ,4000)

