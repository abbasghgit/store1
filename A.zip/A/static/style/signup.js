let styleindex = 1;
function otpStyle(inside,ides){
   styleindex = ides;
   let form = document.querySelector('#'+inside);
   let btn = document.querySelector('#n'+ides);
   let forms =[...document.querySelector('.body').children]
   forms.forEach((element)=>{
      element.classList.remove('active');
   })
   let btns = [...document.querySelector('.title').children]
   btns.forEach((element)=>{
      element.classList.remove('active');
   })
   btn.classList.add('active');
   form.classList.add('active');
}